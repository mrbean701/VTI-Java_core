package Assisgnment1;

public class ExamQuestion {
	Exam examid;
	Question questionid;
}
