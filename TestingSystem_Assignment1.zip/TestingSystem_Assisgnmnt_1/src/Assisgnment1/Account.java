package Assisgnment1;


import java.time.LocalDateTime;

public class Account {
	int accountid;
	String email;
	String username;
	String fullname;
	Department departmentid;
	Position positionid;
	LocalDateTime createdate;
}
