package Assisgnment1;

public class CategoryQuestion {
	int categoryid;
	String categoryname;
}
