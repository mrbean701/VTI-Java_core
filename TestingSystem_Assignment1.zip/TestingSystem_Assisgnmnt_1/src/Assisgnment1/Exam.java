package Assisgnment1;

import java.sql.Time;
import java.time.LocalDateTime;

public class Exam {
	int examid;
	byte code;
	String title;
	CategoryQuestion categoryid;
	Time duration;
	int creatorid;
	LocalDateTime createdate;
}
