package Assisgnment1;

import java.time.LocalDateTime;

public class Question {
	int questionid;
	String content;
	CategoryQuestion categoryid;
	TypeQuestion typeid;
	int creatorid;
	LocalDateTime createdate;
}
