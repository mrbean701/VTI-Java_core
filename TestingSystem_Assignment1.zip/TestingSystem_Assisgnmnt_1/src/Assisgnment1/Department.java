package Assisgnment1;

public class Department {
	int departmentid;
	String departmentname;
}