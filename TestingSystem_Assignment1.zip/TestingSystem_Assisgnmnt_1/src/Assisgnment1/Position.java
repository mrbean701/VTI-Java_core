package Assisgnment1;

public class Position {
	int positionID;
	String positionName;
}
