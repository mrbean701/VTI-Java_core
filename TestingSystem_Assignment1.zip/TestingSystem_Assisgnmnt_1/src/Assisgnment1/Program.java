package Assisgnment1;

public class Program {

	public static void main(String[] args) {
		Department department1 = new Department();
		department1.departmentid = 1;
		department1.departmentname = "Sale";
		
		Department department2 = new Department();
		department2.departmentid = 2;
		department2.departmentname = "Marketting";
		
		Department department3 = new Department();
		department3.departmentid = 3;
		department3.departmentname = "Dev";
		
		Account account1 = new Account();
		account1.accountid = 1;
		account1.email ="email1@gmail.com";
		account1.departmentid = department1;
		
		Account account2 = new Account();
		account2.accountid=2;
		account2.email = "email2@gamil.com";
		account2.departmentid = department2;
		
		Account account3 = new Account();
		account3.accountid = 3;
		account3.email = "email3@gmai.com";
		account3.departmentid = department3;
		
		Group group1 = new Group();
		group1.groupid = 1;
		group1.groupname ="group1";
		group1.creatorid = 1;
		
		Group group2 = new Group();
		group2.groupid = 2;
		group2.groupname = "group2";
		group2.creatorid = 2;
		
		Group group3 = new Group();
		group3.groupid = 1;
		group3.groupname = "group3";
		group3.creatorid = 3;
		
		System.out.println("Department 1: ");
		System.out.println("Name: " + department1.departmentname);
		System.out.println("ID: "+ department1.departmentid);
		System.out.println("\n");
		
		System.out.println("Account 1: "+ account1.accountid);
		System.out.println("Email: "+ account1.email);
		System.out.println("Departmentid: "+ account1.departmentid);
		System.out.println("\n");
		
		System.out.println("Group 1: ");
		System.out.println("ID: " + group1.groupid);
		System.out.println("Name: " + group1.groupname);
		System.out.println("Creator ID: " + group1.creatorid);
		System.out.println("\n");
	}
}
