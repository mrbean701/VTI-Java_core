package Assisgnment1;

public class TypeQuestion {
	int typeid;
	String typename;
}
