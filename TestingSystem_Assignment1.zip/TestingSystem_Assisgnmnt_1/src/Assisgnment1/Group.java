package Assisgnment1;

import java.time.LocalDateTime;

public class Group {
	int groupid;
	String groupname;
	int creatorid;
	LocalDateTime createdate;
}
