package Assisgnment1;

public class Answer {
	int answerid;
	String content;
	Question questionid;
	boolean iscorrect;
}
