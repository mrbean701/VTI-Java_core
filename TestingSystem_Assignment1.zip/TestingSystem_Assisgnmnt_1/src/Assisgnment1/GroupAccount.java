package Assisgnment1;

import java.time.LocalDateTime;

public class GroupAccount {
	Group groupid;
	Account accountid;
	LocalDateTime joindate;
}
