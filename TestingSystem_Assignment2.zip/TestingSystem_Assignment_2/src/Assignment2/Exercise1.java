package Assignment2;

import java.util.Date;

public class Exercise1 {
	private static final int position1 = 0;

	public static void main(String[] args){
		Department department1 = new Department();
		department1.departmentid = 1;
		department1.departmentname ="Sale";
		
		Department department2 = new Department();
		department2.departmentid = 2;
		department2.departmentname ="Marketing";
		
		Department department3 = new Department();
		department3.departmentid = 3;
		department3.departmentname ="Tester";
		
		Position position1 = new Position();
		position1.positionid = 1;
		position1.positionname ="Dev";
		
		Position position2 = new Position();
		position2.positionid = 2;
		position2.positionname = "PM";
		
		Position position3 = new Position();
		position3.positionid = 3;
		position3.positionname = "Test";
		
		Group group1 = new Group();
		group1.createdate = new Date("2019/12/12");
		group1.groupid = 1;
		group1.groupname = "Java Fresher";
		
		Group group2 = new Group();
		group2.createdate = new Date("2019/12/03");
		group2.groupid = 2;
		group2.groupname = "C# Fresher";
		
		Group group3 = new Group();
		group3.createdate = new Date("2019/12/09");
		group3.groupid = 3;
		group3.groupname = "C++ Fresher";
		
		
		Account account1 = new Account();
		account1.accountid =1;
		account1.createdate = new Date("2019/12/02");
		account1.department = department1;
		account1.email = "nguyenvana@gmail.com";
		account1.fullname = "Nguyen Van A";
		account1.position = position1;
		account1.username = "Van A";
		account1.GroupOfAccount = new Group[]{group1, group2};
		
		Account account2 = new Account();
		account2.accountid = 2;
		account2.createdate = new Date("2019/04/06");
		account2.department = department2;
		account2.email = "nguyenvanb@gmail.com";
		account2.fullname = "Nguyen Van B";
		account2.position = position2;
		account2.username = "Van B";
		account2.GroupOfAccount = new Group[]{group1,group2,group3};
		
		Account account3 = new Account();
		account3.accountid =3;
		account3.createdate = new Date("2019/06/08");
		account3.department = department3;
		account3.email = "nguyenvanc@gmail.com";
		account3.fullname = "Nguyen Van C";
		account3.position = position3;
		account3.username = "Van C";
		account3.GroupOfAccount = new Group[]{group3, group2};
		
		
		GroupAccount grc1 = new GroupAccount();
		grc1.account = account1;
		grc1.group = group1;
		grc1.joindate = new Date("2020/02/02");
		
		GroupAccount grc2 = new GroupAccount();
		grc2.account = account2;
		grc2.group = group2;
		grc2.joindate = new Date("2019/12/13");
		
		GroupAccount grc3 = new GroupAccount();
		grc3.account = account3;
		grc3.group = group3;
		grc3.joindate = new Date("2020/01/01");
		
		GroupAccount grc[] = {grc1,grc2,grc3};
		Account account[] ={account1, account2, account3};
		
		Exercise1 ex1 = new Exercise1();

		//Question1
		
		}
	public void question1(Account account2){
		if(account2.department == null){
			System.out.println("Nhân viên này chưa có phòng ban");
		}else if(account2.department != null){
			System.out.println("Phòng ban của nhân viên này là: "+ account2.department);
		}
	}
	
        //Question2
	public void question2(Account account2){
		if(account2.GroupOfAccount.length == 0){
			System.out.println("Nhân viên này chưa có group");
		}else if(account2.GroupOfAccount.length == 1 || account2.GroupOfAccount.length == 2){
			System.out.println("Group của nhân viên này là Java Fresher, C# Fresher");
		}else if(account2.GroupOfAccount.length == 3){
			System.out.println("Nhân viên này là người quan trọng, tham gia nhiều group");
		}else if(account2.GroupOfAccount.length >= 4){
			System.out.println("Nhân viên này là người hóng chuyện, tham gia nhiều group");
		}
	}
	
	    //Question3
	public void question3(Account account2){
		System.out.println(account2.department == null ? "Nhân viên này chưa có phòng ban" : "Phòng ban của nhân viên này là: "+ account2.department.departmentname);
	}
	
	    //Question4
	public void question4(Account account1){
		System.out.println(account1.position.positionname == "Dev" ? "Đây là Developer" : "Người này không phải là Developer");		
	}
	
	//SWITCH CASE
	    
	   //Question5
	public void question5(Group group){
		switch (group.AccountOfGroup.length){
		case 1:
			System.out.println("Nhóm có một thành viên");
			break;
		case 2:
			System.out.println("Nhóm có hai thành viên");
		case 3:
			System.out.println("Nhóm có ba thành viên");
			break;
		default:
		    System.out.println("Nhóm có nhiều thành viên");		
		}
	}
	   //Question6
	public void question6(Account account2){
		
		switch(account2.department.length){
		case 1:
			System.out.println("Group của nhân viên này là Java Fresher, C# Fresher");
			break;
		case 2:
			System.out.println("Group của nhân viên này là Java Fresher, C# Fresher");
			break;
		case 3:
			System.out.println("Nhân viên này là người quan trọng, tham gia nhiều group");
			break;
		case 4:
			System.out.println("Nhân viên này là người hóng chuyện, tham gia tất cả các group");
		}
	}
	public void question7(){
		
	}
}
