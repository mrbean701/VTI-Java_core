package Assignment2;

import java.util.Date;

public class GroupAccount {
	Group group;
	Account account;
	Date joindate;
}
