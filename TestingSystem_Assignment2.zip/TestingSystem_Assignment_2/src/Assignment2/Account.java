package Assignment2;

import java.util.Arrays;
import java.util.Date;

public class Account {
	int accountid;
	String email;
	String username;
	String fullname;
	Department department;
	Position position;
	Date createdate;
	Group[] GroupOfAccount;
	public Position positionid;
	public String toString(){
		return "Account [accountid: " + accountid +" email:" + email +" username: "+ username +" fullname: "+ fullname + " department: "+ department +" position: "+ position +" createdate: "+createdate+" GroupOfAccount: "+ Arrays.toString(GroupOfAccount)+ "]";
	}
}