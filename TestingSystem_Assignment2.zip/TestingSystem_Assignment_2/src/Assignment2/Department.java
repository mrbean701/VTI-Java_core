package Assignment2;

public class Department {
	int departmentid;
	String departmentname;
	public int length;
	
	public String toString(){
		return "Department[departmentid: "+departmentid+" departmentname: "+departmentname+" ]";
	}
}
