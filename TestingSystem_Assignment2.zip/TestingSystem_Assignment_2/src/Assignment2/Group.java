package Assignment2;

import java.util.Date;

public class Group {
	int groupid;
	String groupname;
	int creatorid;
	Date createdate;
	
	Account[] AccountOfGroup;
	public String toString(){
		return groupname;
	}
}