package Assignment2;

public class Position {
	int positionid;
	String positionname;
}
