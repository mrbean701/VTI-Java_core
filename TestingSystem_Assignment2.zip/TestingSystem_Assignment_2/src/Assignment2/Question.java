package Assignment2;

import java.util.Date;

public class Question {
	int questionid;
	String content;
	CategoryQuestion categoryid;
	TypeQuestion typeid;
	int creatorid;
	Date createdate;
	Account creator;
}
