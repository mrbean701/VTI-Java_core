package Assignment2;

public class ExamQuestion {
	Exam examid;
	Question questionid;
}
