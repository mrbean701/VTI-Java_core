package Assignment2;

public class CategoryQuestion {
	int categoryid;
	String categoryname;
}
