package Assignment2;

import java.util.Date;

public class Exam {
	int examid;
	byte code;
	String title;
	CategoryQuestion categoryid;
	int duration;
	int creatorid;
	Date createdate;
	Account creator;
}
