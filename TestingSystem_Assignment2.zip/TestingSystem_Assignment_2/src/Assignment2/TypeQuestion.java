package Assignment2;

public class TypeQuestion {
	int typeid;
	String typename;
}
