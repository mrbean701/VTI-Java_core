package Assignment3;

import java.time.LocalDate;

public class Group {
	   int groupid;
	   String groupname;
	   Account[] accounts;
	   LocalDate createDate;
}
