package Assignment3;

public class Exercise5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
