package Assignment3;

public class CategoryQuestion {
    int id;
    String categoryName;
}
