package Assignment3;

public class TypeQuestion {
    int id;
    String typeName;
}
