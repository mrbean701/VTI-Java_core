package Assignment3;

public class Position {
    int id;
    String name;
}
