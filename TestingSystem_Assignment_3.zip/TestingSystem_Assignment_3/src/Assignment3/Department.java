package Assignment3;

public class Department {
	int id;
	String name;
}
