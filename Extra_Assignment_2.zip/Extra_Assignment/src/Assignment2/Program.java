package Assignment2;

import java.util.Scanner;

public class Program {
/*	public void question1(){
		Scanner sc = new Scanner(System.in);
		double a = sc.nextDouble();;
		double b;
		double c;
		b = a * 2.54;
		c = b * 12;
		System.out.println(a+"cm = "+b+"inch");
		System.out.println(a+"cm = "+c+"foot");
	}*/
/*	public static void question2(){
		Scanner sc = new Scanner(System.in);
		int i = sc.nextInt();
		int h  = 0;
		h = i / 3600;
		int s = 0;
		s =(i -(h * 3600)) / 60;
		int n = i -((h * 3600)+(s * 60));
		
		System.out.println(n);
		System.out.println(h+":"+s+":"+n);
	}*/

	public static void main(String[] args) {
		;
	}
}
