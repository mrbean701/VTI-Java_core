package Assignment2;

import java.util.Scanner;

public class Exercise1 {
	public static void question1(){
		Scanner sc = new Scanner(System.in);
		double a = sc.nextDouble();;
		double b;
		double c;
		b = a * 2.54;
		c = b * 12;
		System.out.println(a+"cm = "+b+"inch");
		System.out.println(a+"cm = "+c+"foot");
	}
	public static void question2(){
		Scanner sc = new Scanner(System.in);
		int i = sc.nextInt();
		int h  = 0;
		h = i / 3600;
		int s = 0;
		s = i % 3600;
		System.out.print(h+":");
	}
	public static void question3(){
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		int d = sc.nextInt();
		int max1 = b,max2 = d, max = max1;
		if(a > b){
			max1 = a;
		}else if(c>d){
			max2 = c;
		}else if(max1 < max2){
			max = max2;
		}
		System.out.println("max = " + max);
		int min1=a,min2=c,min=min1;
		if(a > b && a > d){
			min1 = b;
		}else if(c > d && c > b){
			min2 = d;
		}else if(min1 > min2){
			min = min2;
		}
		System.out.println("min = "+min);
	}
}